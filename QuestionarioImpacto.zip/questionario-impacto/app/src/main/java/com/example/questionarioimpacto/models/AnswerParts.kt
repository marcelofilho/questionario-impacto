package com.example.questionarioimpacto.models

data class AnswerParts(
        val questionPartId: String,
        val text: String
) {
}