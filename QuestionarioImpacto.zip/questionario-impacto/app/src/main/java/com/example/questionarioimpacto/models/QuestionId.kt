package com.example.questionarioimpacto.models

data class QuestionId(
        val oid: String
) {
}