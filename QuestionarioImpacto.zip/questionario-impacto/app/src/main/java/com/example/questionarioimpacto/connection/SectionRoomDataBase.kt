package com.example.questionarioimpacto.connection

import androidx.room.Database


class SectionRoomDataBase {
}