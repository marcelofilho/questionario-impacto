package com.example.questionarioimpacto.viewmodels

import androidx.lifecycle.ViewModel

class IndentificacaoViewModel : ViewModel() {
}