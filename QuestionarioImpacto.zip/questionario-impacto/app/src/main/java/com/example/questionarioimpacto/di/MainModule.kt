package com.example.questionarioimpacto.di

//val mainModule = module{
//
//}